package com.stillcrowdfunding.entity;

import java.util.List;

/**
 * @author Administrator
 * @date 2020/6/15 11:39
 * @description
 **/
public class ParamData {
    private List<Integer> array;

    public ParamData() {

    }

    public List<Integer> getArray() {
        return array;
    }

    public void setArray(List<Integer> array) {
        this.array = array;
    }
}
